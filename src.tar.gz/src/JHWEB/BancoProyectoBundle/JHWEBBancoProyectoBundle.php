<?php

namespace JHWEB\BancoProyectoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JHWEBBancoProyectoBundle extends Bundle
{
}
