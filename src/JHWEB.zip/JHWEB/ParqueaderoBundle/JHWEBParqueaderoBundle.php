<?php

namespace JHWEB\ParqueaderoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JHWEBParqueaderoBundle extends Bundle
{
}
