<?php

namespace JHWEB\GestionDocumentalBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JHWEBGestionDocumentalBundle extends Bundle
{
}
