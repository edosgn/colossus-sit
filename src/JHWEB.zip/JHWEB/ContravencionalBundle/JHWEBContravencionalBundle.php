<?php

namespace JHWEB\ContravencionalBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JHWEBContravencionalBundle extends Bundle
{
}
