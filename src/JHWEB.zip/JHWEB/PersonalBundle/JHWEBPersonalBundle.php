<?php

namespace JHWEB\PersonalBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JHWEBPersonalBundle extends Bundle
{
}
