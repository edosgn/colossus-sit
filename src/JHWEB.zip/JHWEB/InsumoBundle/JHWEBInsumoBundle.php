<?php

namespace JHWEB\InsumoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JHWEBInsumoBundle extends Bundle
{
}
