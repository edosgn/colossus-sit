<?php

namespace JHWEB\FinancieroBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JHWEBFinancieroBundle extends Bundle
{
}
