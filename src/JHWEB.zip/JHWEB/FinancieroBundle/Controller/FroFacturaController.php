<?php

namespace JHWEB\FinancieroBundle\Controller;

use JHWEB\FinancieroBundle\Entity\FroFactura;
use JHWEB\FinancieroBundle\Entity\FroFacComparendo;
use JHWEB\FinancieroBundle\Entity\FroFacTramite;
use JHWEB\ContravencionalBundle\Entity\CvCdoTrazabilidad;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use CodeItNow\BarcodeBundle\Utils\BarcodeGenerator;

/**
 * FrofroFactura controller.
 *
 * @Route("froFactura")
 */
class FroFacturaController extends Controller
{
    /**
     * Lists all cvCfgIntere entities.
     *
     * @Route("/", name="froFactura_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $helpers = $this->get("app.helpers");

        $em = $this->getDoctrine()->getManager();
        
        $facturas = $em->getRepository('JHWEBFinancieroBundle:FroFactura')->findBy(
            array(
                'activo' => true
            )
        );

        $response['data'] = array();

        if ($facturas) {
            $response = array(
                'status' => 'success',
                'code' => 200,
                'message' => count($facturas)." registros encontrados", 
                'data'=> $facturas,
            );
        }

        return $helpers->json($response);
    }

    /**
     * Creates a new cvCfgIntere entity.
     *
     * @Route("/new", name="froFactura_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
        $helpers = $this->get("app.helpers");
        $hash = $request->get("authorization", null);
        $authCheck = $helpers->authCheck($hash);

        if ($authCheck== true) {
            $json = $request->get("data",null);
            $params = json_decode($json);

            $em = $this->getDoctrine()->getManager();
           
            $factura = new FroFactura();

            $fechaCreacion = new \Datetime(date('Y-m-d'));

            $factura->setFechaCreacion($fechaCreacion);
            $factura->setFechaVencimiento($fechaCreacion->modify('+1 days'));
            $factura->setHora(new \Datetime(date('h:i:s A')));
            $factura->setValorBruto($params->valor);
            $factura->setValorMora($params->interes);
            $factura->setValorNeto($params->valor + $params->interes);
            //$factura->setEstado('EMITIDA');
            $factura->setEstado('PAGADA');
            $factura->setActivo(true);

            $consecutivo = $em->getRepository('JHWEBFinancieroBundle:FroFactura')->getMaximo(date('Y'));
           
            $consecutivo = (empty($consecutivo['maximo']) ? 1 : $consecutivo['maximo']+=1);
            $factura->setConsecutivo($consecutivo);
            
            $factura->setNumero(
                $fechaCreacion->format('Y').$fechaCreacion->format('m').str_pad($consecutivo, 3, '0', STR_PAD_LEFT)
            );
            
            if ($params->idOrganismoTransito) {
                $organismoTransito = $em->getRepository('JHWEBConfigBundle:CfgOrganismoTransito')->find(
                    $params->idOrganismoTransito
                );
                $factura->setOrganismoTransito($organismoTransito);
            }

            if ($params->idTipoRecaudo) {
                $tipoRecaudo = $em->getRepository('JHWEBFinancieroBundle:FroCfgTipoRecaudo')->find(
                    $params->idTipoRecaudo
                );
                $factura->setTipoRecaudo($tipoRecaudo);
            }

            $em->persist($factura);
            $em->flush();

            if (isset($params->comparendos)) {
                $this->registerComparendos($params->comparendos, $factura);
            }elseif (isset($params->tramites)) {
                $this->registerTramites($params->tramites, $factura);
            }

            // foreach ($params->tramitesValor as $key => $tramiteValor) {
                
            //     $tramiteFactura = new TramiteFactura();

            //     $tramitePrecio = $em->getRepository('JHWEBFinancieroBundle:FroTrtePrecio')->find(
            //         $tramiteValor->idTramitePrecio
            //     );

            //     if($tramitePrecio->getTramite()->getId() == 6){   
            //         foreach ($params->propietarios as $key => $propietarioRetefuenteId) {
                    
            //             $mflRetefuente = new MflRetefuente();

            //             $mflRetefuente->setVehiculo($vehiculo);
                        
            //             $propietarioVehiculo = $em->getRepository('JHWEBVehiculoBundle:VhloPropietario')->find( 
            //                 $propietarioRetefuenteId
            //             );

            //             $mflRetefuente->setPropietarioVehiculo($propietarioVehiculo);
 
            //             if (isset($params->valorVehiculoId)) {
            //                 $valorVehiculo = $em->getRepository('JHWEBVehiculoBundle:VhloCfgValor')->find(
            //                     $params->valorVehiculoId
            //                 );
            //                 $mflRetefuente->setValorVehiculo($valorVehiculo);
            //             }
            //             $mflRetefuente->setFactura($factura);
            //             $mflRetefuente->setFecha(new \DateTime($params->factura->fechaCreacion));
            //             $mflRetefuente->setRetencion($params->retencion);
            //             $mflRetefuente->setEstado(true);
            //             $em->persist($mflRetefuente);
            //             $em->flush();
            //         }
            //     }

            //     $tramiteFactura->setFactura($factura);
            //     $tramiteFactura->setTramitePrecio($tramitePrecio);
            //     $tramiteFactura->setEstado(true);
            //     $tramiteFactura->setRealizado(false);
            //     $tramiteFactura->setCantidad(1);
            //     $em->persist($tramiteFactura);
            //     $em->flush();
            // }

            $response = array(
                'status' => 'success',
                'code' => 200,
                'message' => 'Factura No. '.$factura->getNumero().' creada con exito.',
                'data' => $factura
            );
        }else{
            $response = array(
                'status' => 'error',
                'code' => 400,
                'message' => 'Autorizacion no valida.', 
            );
        }

        return $helpers->json($response);
    }

    /* =================================== */

    /**
     * Creates a new cvCfgIntere entity.
     *
     * @Route("/new/amortizacion", name="froFactura_new_amortizacion")
     * @Method({"GET", "POST"})
     */
    public function newAmortizacionAction(Request $request)
    {
        $helpers = $this->get("app.helpers");
        $hash = $request->get("authorization", null);
        $authCheck = $helpers->authCheck($hash);

        if ($authCheck== true) {
            $json = $request->get("data",null);
            $params = json_decode($json);

            $em = $this->getDoctrine()->getManager();
           
            $factura = new FroFactura();

            $fechaCreacion = new \Datetime(date('Y-m-d'));

            if ($params->idAmortizacion) {
                $amortizacion = $em->getRepository('JHWEBFinancieroBundle:FroAmortizacion')->find(
                    $params->idAmortizacion
                );
            }

            $factura->setFechaCreacion($fechaCreacion);
            $factura->setFechaVencimiento($fechaCreacion->modify('+1 days'));
            $factura->setHora(new \Datetime(date('h:i:s A')));
            $factura->setValorBruto($amortizacion->getValorBruto());
            $factura->setValorMora($amortizacion->getValorMora());
            $factura->setValorNeto($amortizacion->getValorNeto());
            $factura->setEstado('EMITIDA');
            $factura->setActivo(true);

            $consecutivo = $em->getRepository('JHWEBFinancieroBundle:FroFactura')->getMaximo(date('Y'));
           
            $consecutivo = (empty($consecutivo['maximo']) ? 1 : $consecutivo['maximo']+=1);
            $factura->setConsecutivo($consecutivo);
            
            $factura->setNumero(
                $fechaCreacion->format('Y').$fechaCreacion->format('m').str_pad($consecutivo, 3, '0', STR_PAD_LEFT)
            );
            
            if ($params->idOrganismoTransito) {
                $organismoTransito = $em->getRepository('JHWEBConfigBundle:CfgOrganismoTransito')->find(
                    $params->idOrganismoTransito
                );
                $factura->setOrganismoTransito($organismoTransito);
            }

            if ($params->idTipoRecaudo) {
                $tipoRecaudo = $em->getRepository('JHWEBFinancieroBundle:FroCfgTipoRecaudo')->find(
                    $params->idTipoRecaudo
                );
                $factura->setTipoRecaudo($tipoRecaudo);
            }

            $em->persist($factura);
            $em->flush();

            $amortizacion->setFactura($factura);
            $em->flush();

            $response = array(
                'status' => 'success',
                'code' => 200,
                'message' => "Factura No.".$factura->getNumero()." creada con exito",
                'data' => $factura
            );
        }else{
            $response = array(
                'status' => 'error',
                'code' => 400,
                'message' => "Autorizacion no valida", 
            );
        }

        return $helpers->json($response);
    }

    /* =================================== */

    /**
     * busca vehiculos por id.
     *
     * @Route("/search/numero", name="froFactura_search_numero")
     * @Method({"GET", "POST"})
     */
    public function searchByNumero(Request $request)
    {
        $helpers = $this->get("app.helpers");
        $hash = $request->get("authorization", null);
        $authCheck = $helpers->authCheck($hash);


        if ($authCheck == true) {
            $json = $request->get("data",null);
            $params = json_decode($json);

            $em = $this->getDoctrine()->getManager();

            $froFactura = $em->getRepository('JHWEBFinancieroBundle:FroFactura')->findOneBy(
                array(
                    'numero' => $params->numeroFactura,
                )
            );

            if ($froFactura) {
                if ($froFactura->getEstado() != 'FINALIZADA') {
                    if ($froFactura->getEstado() == 'PAGADA' || $froFactura->getEstado() == 'PENDIENTE DOCUMENTACION') {
                        $response = array(
                            'status' => 'success',
                            'code' => 200,
                            'message' => 'Factura pagada.', 
                            'data'=> $froFactura
                        );
                    }else{
                        $response = array(
                            'status' => 'error',
                            'code' => 400,
                            'message' => 'Factura pendiente de pago.' 
                        );
                    }
                }else{
                    $response = array(
                        'status' => 'error',
                        'code' => 400,
                        'message' => 'La factura ya fue tramitada y se encuentra finalizada.' 
                    );
                }
            }else{
                $response = array(
                    'status' => 'error',
                    'code' => 400,
                    'message' => 'La factura no existe.' 
                );
            }
        }else{
            $response = array(
                'status' => 'error',
                'code' => 400,
                'message' => "Autorizacion no valida", 
            );
        } 
        return $helpers->json($response);
    }

    /**
     * Calcula el valor según los comparendos seleecionados.
     *
     * @Route("/calculate/value", name="froFactura_calculate_value")
     * @Method("POST")
     */
    public function calculateValueByComparendosAction(Request $request)
    {
        $helpers = $this->get("app.helpers");
        $hash = $request->get("authorization", null);
        $authCheck = $helpers->authCheck($hash);

        if ($authCheck == true) {
            $json = $request->get("json", null);
            $params = json_decode($json);

            $em = $this->getDoctrine()->getManager();

            $totalPagar = 0;
            $totalInteres = 0;

            foreach ($params as $key => $comparendoSelect) {
                $comparendo = $em->getRepository('AppBundle:Comparendo')->find(
                    $comparendoSelect->id
                );

                $interes = 0;
                $valorPagar = 0;

                if ($comparendo) {                   
                    $diasHabiles = $helpers->getDiasHabiles($comparendo->getFecha());

                    if ($diasHabiles < 6 && $comparendoSelect->curso) {
                        $valorPagar = $comparendo->getValorInfraccion() / 2;
                    }elseif($diasHabiles > 5 && $diasHabiles < 21 && $comparendoSelect->curso){
                        $valorPagar = $comparendo->getValorInfraccion() - ($comparendo->getValorInfraccion() * 0.25);
                    }else{
                        if ($comparendo->getEstado()->getId() == 1 || $comparendo->getEstado()->getId() == 2 || $comparendo->getEstado()->getId() == 3) {

                            if ($comparendo->getEstado()->getId() == 2 || $comparendo->getEstado()->getId() == 3) {
                                //Busca la sanción en la trazabilidad del comparendo
                                $trazabilidad = $em->getRepository('JHWEBContravencionalBundle:CvCdoTrazabilidad')->findOneBy(
                                    array(
                                        'comparendo' => $comparendo->getId(),
                                        'estado' => 2
                                    )
                                );

                                $diasCalendario = $helpers->getDiasCalendario($trazabilidad->getFecha());

                                $porcentajeInteres = $em->getRepository('JHWEBContravencionalBundle:CvCfgInteres')->findOneByActivo(
                                   true
                                );

                                $interes = $comparendo->getValorInfraccion() * ($porcentajeInteres->getValor() / 100);
                                $interes = $interes * $diasCalendario;
                            }
                            $totalInteres = $totalInteres + $interes;
                            $valorPagar = $comparendo->getValorInfraccion() + $interes;
                        }
                    }

                    $totalPagar += $valorPagar;
                }
            }
            
            $response = array(
                'status' => 'success',
                'code' => 200,
                'message' => 'Calculo generado',
                'data' => array(
                    'totalPagar' => round($totalPagar),
                    'totalInteres'=> round($totalInteres)
                )
            );
        } else {
            $response = array(
                'status' => 'error',
                'code' => 400,
                'message' => "Autorizacion no valida",
            );
        }

        return $helpers->json($response);
    }

    /**
     * Registra los comparendos según la factura y calcula el valor según los comparendos seleccionados y actualiza los valores.
     */
    public function registerComparendos($params, $factura)
    {
        $helpers = $this->get("app.helpers");

        $em = $this->getDoctrine()->getManager();

        $totalPagar = 0;
        $totalInteres = 0;

        foreach ($params as $key => $comparendoSelect) {
            $comparendo = $em->getRepository('AppBundle:Comparendo')->find(
                $comparendoSelect->id
            );

            //Inserta la relación de factura con comparendos seleccionados
            $facturaComparendo = new FroFacComparendo();

            $facturaComparendo->setFactura($factura);
            $facturaComparendo->setComparendo($comparendo);

            $em->persist($facturaComparendo);
            $em->flush();

            $interes = 0;

            if ($comparendo) {
                //Actualiza el estado del curso
                if ($comparendoSelect->curso) {
                    $comparendo->setCurso(true);
                }else{
                    $comparendo->setCurso(false);
                }
                
                $diasHabiles = $helpers->getDiasHabiles($comparendo->getFecha());

                if ($diasHabiles < 6 && $comparendoSelect->curso) {
                    $comparendo->setValorPagar($comparendo->getValorInfraccion() / 2);
                    $comparendo->setPorcentajeDescuento(50);
                }elseif($diasHabiles > 5 && $diasHabiles < 21 && $comparendoSelect->curso){
                    $comparendo->setValorPagar(
                        $comparendo->getValorInfraccion() - ($comparendo->getValorInfraccion() * 0.25)
                    );
                    $comparendo->setPorcentajeDescuento(25);
                }else{
                    $comparendo->setPorcentajeDescuento(0);

                    if ($comparendo->getEstado()->getId() == 1 || $comparendo->getEstado()->getId() == 2 || $comparendo->getEstado()->getId() == 3) {
                        if ($comparendo->getEstado()->getId() == 2 || $comparendo->getEstado()->getId() == 3) {
                            //Busca la sanción en la trazabilidad del comparendo
                            $trazabilidad = $em->getRepository('JHWEBContravencionalBundle:CvCdoTrazabilidad')->findOneBy(
                                array(
                                    'comparendo' => $comparendo->getId(),
                                    'estado' => 2
                                )
                            );

                            $diasCalendario = $helpers->getDiasCalendario($trazabilidad->getFecha());

                            $porcentajeInteres = $em->getRepository('JHWEBContravencionalBundle:CvCfgInteres')->findOneByActivo(
                               true
                            );

                            $interes = $comparendo->getValorInfraccion() * ($porcentajeInteres->getValor() / 100);
                            $interes = $interes * $diasCalendario;
                        }
                        $totalInteres = $totalInteres + $interes;

                        $comparendo->setInteresMora($interes);
                        $comparendo->setValorPagar(
                            $comparendo->getValorInfraccion() + $interes
                        );
                    }
                }

                $em->flush();

                $totalPagar += $comparendo->getValorPagar();
            }
        }

        return true;
    }

    /**
     * Registra los trámites según la factura.
     */
    public function registerTramites($params, $factura)
    {
        $helpers = $this->get("app.helpers");

        $em = $this->getDoctrine()->getManager();

        foreach ($params as $key => $tramitePrecioSelect) {
            $tramitePrecio = $em->getRepository('JHWEBFinancieroBundle:FroTrtePrecio')->find(
                $tramitePrecioSelect->id
            );

            //Inserta la relación de factura con trámites seleccionados
            $facturaTramite = new FroFacTramite();

            $facturaTramite->setFactura($factura);
            $facturaTramite->setPrecio($tramitePrecio);
            $facturaTramite->setRealizado(false);
            $facturaTramite->setActivo(true);

            $em->persist($facturaTramite);
            $em->flush();
        }

        return true;
    }

    /**
     * Genera pdf de factura seleccionada.
     *
     * @Route("/{tipoRecaudo}/{id}/pdf", name="froFactura_pdf")
     * @Method("GET")
     */
    public function pdfAction(Request $request, $tipoRecaudo, $id)
    {
        switch ($tipoRecaudo) {
            case 1:
                $this->generatePdfTramites($id);
                break;
            
            case 2:
                $this->generatePdfInfracciones($id);
                break;

            case 3:
                $this->generatePdfAmortizacion($id);
                break;
        }


    }

    protected function generatePdfTramites($id){
        $em = $this->getDoctrine()->getManager();

        setlocale(LC_ALL,"es_ES");
        $fechaActual = strftime("%d de %B del %Y");

        $factura = $em->getRepository('JHWEBFinancieroBundle:FroFactura')->find($id);

        $tramites = $em->getRepository('JHWEBFinancieroBundle:FroFacTramite')->findBy(
            array(
                'factura' => $factura->getId()
            )
        );

        $barcode = new BarcodeGenerator();
        $barcode->setText('(415)7709998017603(8020)02075620756(8020)'.$factura->getNumero().'(3900)'.$factura->getValorNeto().'(96)'.$factura->getFechaVencimiento()->format('Ymd'));
        $barcode->setNoLengthLimit(true);
        $barcode->setAllowsUnknownIdentifier(true);
        $barcode->setType(BarcodeGenerator::Gs1128);
        $barcode->setScale(1);
        $barcode->setThickness(25);
        $barcode->setFontSize(7);
        $imgBarcode = $barcode->generate();

        //$imgBarcode = \base64_decode($imgBarcode);
        $html = $this->renderView('@JHWEBFinanciero/Default/pdf.factura.tramites.html.twig', array(
            'fechaActual' => $fechaActual,
            'factura'=>$factura,
            'tramites'=>$tramites,
            'imgBarcode' => $imgBarcode
        ));

        $this->get('app.pdf')->templateSummary($html, $factura);
    }

    protected function generatePdfInfracciones($id){
        $em = $this->getDoctrine()->getManager();

        setlocale(LC_ALL,"es_ES");
        $fechaActual = strftime("%d de %B del %Y");

        $factura = $em->getRepository('JHWEBFinancieroBundle:FroFactura')->find($id);

        $comparendos = $em->getRepository('JHWEBFinancieroBundle:FroFacComparendo')->findBy(
            array(
                'factura' => $factura->getId()
            )
        );

        $barcode = new BarcodeGenerator();
        $barcode->setText(
            '(415)7709998017603(8020)02075620756(8020)'.$factura->getNumero().'(3900)'.$factura->getValorNeto().'(96)'.$factura->getFechaVencimiento()->format('Ymd')
        );
        $barcode->setNoLengthLimit(true);
        $barcode->setAllowsUnknownIdentifier(true);
        $barcode->setType(BarcodeGenerator::Gs1128);
        $barcode->setScale(1);
        $barcode->setThickness(25);
        $barcode->setFontSize(7);
        $code = $barcode->generate();

        //$imgBarcode = \base64_decode($code);
        $imgBarcode = $code;

        $html = $this->renderView('@JHWEBFinanciero/Default/pdf.factura.infracciones.html.twig', array(
            'fechaActual' => $fechaActual,
            'factura'=>$factura,
            'comparendos'=>$comparendos,
            'imgBarcode' => $imgBarcode
        ));

        $this->get('app.pdf')->templateFactura($html, $factura);
    }

    protected function generatePdfAmortizacion($idFactura){
        $em = $this->getDoctrine()->getManager();

        setlocale(LC_ALL,"es_ES");
        $fechaActual = strftime("%d de %B del %Y");

        $factura = $em->getRepository('JHWEBFinancieroBundle:FroFactura')->find($id);

        if ($factura) {
            $fechaCreacion = new \Datetime(date('Y-m-d'));

            $factura->setFechaCreacion($fechaCreacion);
            $factura->setFechaVencimiento($fechaCreacion->modify('+1 days'));
            $factura->setHora(new \Datetime(date('h:i:s A')));

            $em->flush();
        }

        $amortizacion = $em->getRepository('JHWEBFinancieroBundle:FroFacComparendo')->findOneByFactura($factura->getId());

        $barcode = new BarcodeGenerator();
        $barcode->setText(
            '(415)7709998017603(8020)02075620756(8020)'.$factura->getNumero().'(3900)'.$factura->getValorNeto().'(96)'.$factura->getFechaVencimiento()->format('Ymd')
        );
        $barcode->setNoLengthLimit(true);
        $barcode->setAllowsUnknownIdentifier(true);
        $barcode->setType(BarcodeGenerator::Gs1128);
        $barcode->setScale(1);
        $barcode->setThickness(25);
        $barcode->setFontSize(7);
        $code = $barcode->generate();

        //$imgBarcode = \base64_decode($code);
        $imgBarcode = $code;

        $html = $this->renderView('@JHWEBFinanciero/Default/pdf.factura.infracciones.html.twig', array(
            'fechaActual' => $fechaActual,
            'factura'=>$factura,
            'comparendos'=>$comparendos,
            'imgBarcode' => $imgBarcode
        ));

        $this->get('app.pdf.factura')->templateFactura($html, $factura);
    }
}
