<?php

namespace JHWEB\ConfigBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JHWEBConfigBundle extends Bundle
{
}
